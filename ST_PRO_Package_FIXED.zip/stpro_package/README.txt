╔══════════════════════════════════════════════════════════════╗
║               ST PRO — Release Package                       ║
║         User-Scoped Storage Security Fix — June 2026         ║
╚══════════════════════════════════════════════════════════════╝

CONTENTS
────────
  index.html            ← The complete app (single file)
  ST_PRO_Datasheet.docx ← Full technical datasheet & developer guide
  README.txt            ← This file


QUICK START
───────────
1. Open ST_PRO_Datasheet.docx and read Section 8 (Configuration).
2. In index.html, find and set:
     const GOOGLE_CLIENT_ID = 'your-client-id.apps.googleusercontent.com';
     const ADMIN_EMAIL      = 'your@gmail.com';
3. Upload index.html to any static host (GitHub Pages, Netlify, etc.).
4. Place manifest.json, sw.js, and icon PNG files alongside it.
5. Open the hosted URL in Chrome/Safari and test login.


WHAT CHANGED IN THIS VERSION (security fix)
────────────────────────────────────────────
PROBLEM:
  All users on the same browser shared the same localStorage keys.
  alice@gmail.com's study history, subjects, and MCQ sheets were
  visible to and shared with bob@gmail.com on the same device.

FIX:
  A transparent localStorage proxy now prefixes every app-data key
  with the logged-in user's email address:

    alice@gmail.com:all-history   (Alice's sessions)
    bob@gmail.com:all-history     (Bob's sessions — separate)

  Zero app code was changed. The proxy intercepts getItem/setItem/
  removeItem calls transparently.

ALSO FIXED:
  • "Cannot access 'gUser' before initialization" TDZ crash
    → gUser pre-declared with `var` above the proxy IIFE
  • resetAllData() now deletes only the current user's keys
  • createBackup() and gDriveBackup() collect only the current
    user's data (not all users' data)
  • First-login migration: existing unscoped data is automatically
    copied to the user-scoped keys on first login after this update


FILES YOU STILL NEED (not included — host-specific)
────────────────────────────────────────────────────
  manifest.json   — PWA manifest (name, icons, theme_color, start_url)
  sw.js           — Service worker for offline caching
  icon-192.png    — App icon (192×192)
  icon-512.png    — App icon (512×512)
  icon-152.png    — Apple touch icon (152×152, optional)


FOR FULL DETAILS
────────────────
  See ST_PRO_Datasheet.docx — it covers:
  • Architecture overview          (Section 2)
  • Google auth flow               (Section 3)
  • Storage proxy internals        (Section 4)
  • All key functions              (Section 5)
  • Admin panel                    (Section 6)
  • Data schemas (JSON formats)    (Section 7)
  • Deployment checklist           (Section 9)
  • Developer hints & gotchas      (Section 10)
  • Troubleshooting guide          (Section 11)
  • Quick Reference Card           (last page)
