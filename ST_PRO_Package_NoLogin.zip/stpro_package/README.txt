╔══════════════════════════════════════════════════════════════╗
║               ST PRO — Release Package                       ║
║              Single-User / No Login — June 2026              ║
╚══════════════════════════════════════════════════════════════╝

CONTENTS
────────
  index.html            ← The complete app (single file)
  ST_PRO_Datasheet.docx ← Original technical datasheet (see note below)
  README.txt            ← This file


QUICK START
───────────
1. Just open index.html in Chrome/Safari (double-click it, or upload
   it to any static host — GitHub Pages, Netlify, etc.). That's it.
2. No setup, no sign-in screen, no admin email, no client ID.
   The app works immediately and stores everything in your
   browser's local storage on this device.


WHAT CHANGED IN THIS VERSION
─────────────────────────────
Removed entirely:
  • Google Sign-In screen, "Access Denied" screen, and the
    3-day inactivity lock screen
  • Admin Panel (allowed-users list + "Friends' Data" viewer)
  • Google Drive backup/restore and the auto-share-with-admin
    behaviour
  • The user-scoped localStorage proxy (every key was being
    prefixed with your email — no longer needed for one user)
  • The account badge in the top-right corner

Kept (still works exactly as before):
  • "Manage" menu (⋮ on the home screen): Add subject, Edit task
    list, Set daily goal, Study reminder, Backup my data, Restore
    from backup, Reset ALL data
  • Local JSON backup/restore (download a .json file, restore it
    later — no Google account involved)
  • The "Welcome" restore banner on a fresh install


FILES YOU STILL NEED FOR A PWA (not included — host-specific)
────────────────────────────────────────────────────────────
  manifest.json   — PWA manifest (name, icons, theme_color, start_url)
  sw.js           — Service worker for offline caching
  icon-192.png    — App icon (192×192)
  icon-512.png    — App icon (512×512)
  icon-152.png    — Apple touch icon (152×152, optional)

These are only needed if you want "Add to Home Screen" / offline
support. The app itself runs fine without them — just open
index.html.


ABOUT THE DATASHEET (ST_PRO_Datasheet.docx)
────────────────────────────────────────────
This is the original developer datasheet from the previous
package. Its sections on Google auth flow, the storage proxy,
and the Admin panel (Sections 3, 4 and 6) no longer apply to this
version — that code has been removed. Everything else (data
schemas, key functions for the study/MCQ/task features, etc.)
still describes this build. Let me know if you'd like an updated
datasheet that drops those sections.
